<?php include("../../lib/opin.inc.php")?>
<?php define("CPAGE","adm/")?>
<?php include("../inc/header.inc.php");?>
<div class="main">
<?php include "../inc/header2.php"; ?>
<div class="content">
<div class="div-tbl">
<div class="cl"></div>
	<? //$adm->h1_tag('Dashboard &rsaquo; Email Alerts Manager',((!$mode)?$others:$others2))?>
<?php $hedtitle = "CMS User Management"; ?>  
<?php 
if($_SESSION["ses_adm_type"]=='user'){ 
$id = $_SESSION["ses_adm_id"];
$updateid = $_SESSION["ses_adm_id"];
}
$email_update=mysql_num_rows($rsAdmin=$cms->db_query("select * from #_administrator where aemail='".$aemail."' and aid!='".$updateid."' "));
$email_insert= mysql_num_rows($rsAdmin=$cms->db_query("select * from #_administrator where aemail='".$aemail."' "));
if($cms->is_post_back() && $_POST[admreg]=='1'){
	$_POST[apassword] = base64_encode($apassword);
	if($updateid){ 
	   if(!mysql_num_rows($rsAdmin=$cms->db_query("select * from #_administrator where ausername='".$ausername."' and aid!='".$updateid."' "))){
		 if(!$email_update){
				$cms->sqlquery("rs","administrator",$_POST,'aid',$updateid);
				$adm->sessset('Record has been updated', 's');
				$cms->redir(SITE_PATH_ADM.CPAGE, true);
		  }else{
		         $adm->sessset('Email already exist', 'e');
		  }	
	  }else{
			$adm->sessset('User already exist', 'e');
		} 
	}else { 
	if(!mysql_num_rows($cms->db_query("select aemail from #_administrator where  ausername='".$ausername."'"))){
		if(!$email_insert){
			$_POST[submitdate] = time();
			$cms->sqlquery("rs","administrator",$_POST);
			$adm->sessset('Record has been added', 's');
			$cms->redir(SITE_PATH_ADM.CPAGE, true);
		} else {
			$adm->sessset('Email already exist', 'e');
		}
    }else{   
	       $adm->sessset('User already exist', 'e');
		    
	}	
  }	
}

if(isset($id)){
	$rsAdmin=$cms->db_query("select * from #_administrator where aid='".$id."'");
	$arrAdmin=$cms->db_fetch_array($rsAdmin);
	@extract($arrAdmin);
}
 
?>
    <?=$adm->alert()?>
      <div class="title"  id="innertit">
           <?=$adm->heading(((!$mode)?'CMS User Manager':'Add/Update CMS User'))?>
        </div>
      <div class="tbl-contant"><?php if($mode || $_SESSION["ses_adm_type"]=='user'){include("add.php");}else{include("manage.php");}?></div>
       <div class="cl"></div>
    </div>
  </div> 
<?php include("../inc/footer.inc.php")?></div>
</div>
<div class="cl"></div>
</div>
</div>

<script type="text/javascript">
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
var Accordion1 = new Spry.Widget.Accordion("Accordion1");
</script>
</body>
</html>
