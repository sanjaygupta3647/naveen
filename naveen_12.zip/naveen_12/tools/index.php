<?php include("../lib/opin.inc.php")?>
<?php include_once "inc/header.inc.php"; ?>
 
 <div class="main"> 
 
 <header>
   
  <div class="hrd-right-wrap">
  
  
     
    <div class="brdcm">
      Dashboard
    </div>
  </div>
  <div class="cl"></div>
</header>
    <div class="content">
       
           
           
       <? //include_once "quicklinks.php";?>
 
        <?  //include"dashboad.php"; ?> 
     
       
    </div>
      <? include"inc/footer.inc.php"; ?>
  </div>
  <div class="cl"></div>
</div>
</div>
<script type="text/javascript">
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
var Accordion1 = new Spry.Widget.Accordion("Accordion1");
</script>
</body>
</html>
