<?php defined('_JEXEC') or die('Restricted access'); error_reporting(E_ERROR | E_PARSE); ?>
<?php 
if($cms->is_post_back()){ 
	 
	if($updateid){
		$cms->sqlquery("rs","category",$_POST,'pid',$updateid);
		$adm->sessset('Record has been updated', 's');
	}else{
		//$_POST[submitdate] = time();
		$cms->sqlquery("rs","category",$_POST);
		$adm->sessset('Record has been added', 's');
		$updateid=mysql_insert_id();
	}
	$cms->redir(SITE_PATH_ADM.CPAGE, true);
}	
if(isset($id)){
	$rsAdmin=$cms->db_query("select * from #_category where pid='".$id."'");
	$arrAdmin=$cms->db_fetch_array($rsAdmin);
	@extract($arrAdmin);
}
?> 
  
 <script src="datetimepicker_css.js"></script>
 
  <table width="100%" border="0" align="left" cellpadding="4" cellspacing="1" class="frm-tbl2">  
	<tr  class="grey_">
            <td width="25%" class="label">Under Category:</td>
            <td width="75%">  
            <select name="parentId" class="txt">
          <option value="0">----Root Category----</option>
          <?php $rsAdmin_=$cms->db_query("select pid,name from #_category where `status`='Active' and `parentId`='0' order by name ");
	 		 while($arrAdmin_=$cms->db_fetch_array($rsAdmin_)){ ?>
            <option value="<?=$arrAdmin_[pid]?>" <?=(($parentId==$arrAdmin_[pid])?'selected="selected"':'')?>>
             <?=$arrAdmin_[name]?>
          </option>
          <?php  } ?>
        </select>
          </td>
          </tr>
            
          <tr  class="grey_">
            <td width="25%" class="label">Name:</td>
            <td width="75%"><input name="name" type="text" class="txt medium" id="name" value="<?=$name?>" /></td>
          </tr>
         <?php if($image and file_exists(UP_FILES_FS_PATH."/orginal/".$image)){?> 
         <tr>
          <td valign="top"  class="label"></td>
          <td><img src="<?=SITE_PATH."uploaded_files/orginal/".$image?>"?> </td>
         </tr>
         <?php } ?>
           <tr>
            <td valign="top" class="label">Image:</td>
            <td valign="top"><input type="text" name="image" value="<?=$image?>" class="txt medium" id="upimg" />
    <img  class="img-click" onClick="window.open('<?=SITE_PATH_ADM."crop/imageupload.php?imgid=upimg&image=category"?>','mywindow','width=800,height=400,left=200,scrollbars=yes, top=100,screenX=0,screenY=100')" src="<?=SITE_PATH_ADM?>images/clickhere.png" alt="" /></td>
          </tr>
          <tr>
            <td valign="top" class="label">Description:</td>
            <td valign="top"><textarea name="body" cols="40" rows="3" id="body"><?=$body?></textarea></td>
          </tr>
          <tr>
            <td class="label">Status:<span>*</span></td>
            <td><select name="status"  class="txt" lang="R" title="Status">
                <option value="Active" <?=(($status=='Active')?'selected="selected"':'')?>>Active</option>
                <option value="Inactive" <?=(($status=='Inactive')?'selected="selected"':'')?>>Inactive</option>
              </select></td>
          </tr>
          
          <tr>
            <td>&nbsp;</td>
            <td><input type="submit" name="Submit" class="uibutton  loading" value="&nbsp;&nbsp;&nbsp;Submit&nbsp;&nbsp;&nbsp;" /></td>
          </tr>
  </table>
   
 