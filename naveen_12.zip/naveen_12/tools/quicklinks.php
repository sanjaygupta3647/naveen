<div class="div-tbl ">
        <div class="title"><img src="images/section-icon.png" alt="">Quick Links</div>
        <div class="tbl-contant">
          <div class="sb-wrap-all">
            <div class="sb-wrap"><!--<span class="notification">5</span> --><a href="<?=SITE_PATH_ADM?>cms/" class="section-box"> <span>Content</span> Manager </a> </div>

            <div class="sb-wrap"> <a href="<?=SITE_PATH_ADM?>seo/" class="section-box"> <span>SEO</span> Manager </a> </div>
            <div class="sb-wrap"> <a href="<?=SITE_PATH_ADM?>adm/" class="section-box"><span>CMS</span> User </a> </div>
            <div class="sb-wrap"><!--<span class="notification">10</span> -->
            <a href="<?=SITE_PATH_ADM?>members/"class="section-box"> <span>Member</span> Manager </a> </div>
            <div class="sb-wrap"> <a href="<?=SITE_PATH_ADM?>news/" class="section-box"> <span>News </span> Manager </a> </div>
            <div class="sb-wrap"><!-- <span class="notification">7</span>-->
            <a href="<?=SITE_PATH_ADM?>brochures/" class="section-box"> <span>Borchures</span> Manager </a> </div>
            <div class="sb-wrap"> <a href="<?=SITE_PATH_ADM?>catalog/collections.php" class="section-box">Catalog Manager </a> </div>
            <div class="sb-wrap"> <a href="<?=SITE_PATH_ADM?>gallery/" class="section-box"> <span>Gallery</span> Manager </a> </div>
            <div class="sb-wrap"> <a href="<?=SITE_PATH_ADM?>banner/" class="section-box"> <span>Banner </span> Manager </a> </div>
            <div class="sb-wrap"> <!--<span class="notification">15</span>--><a  href="<?=SITE_PATH_ADM?>shipping/" class="section-box"> <span>Shipping</span> Manager </a> </div>
            <div class="sb-wrap"> <a href="<?=SITE_PATH_ADM?>catalog/manage-orders.php" class="section-box"><span>All</span> Orders </a> </div>
          </div>
        </div>
      </div>
        <div class="cl2"></div>