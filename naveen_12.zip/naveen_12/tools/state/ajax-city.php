  
<?php include("../../lib/opin.inc.php");
if($_GET[state])
{?>
      <select name="city" title="city" class="select" lang="R" title="City">
	  <select name="city_id"  <?php
     $rsAdmin=$cms->db_query("select * from #_state where state = '".$_GET[state]."'");
if(mysql_num_rows($rsAdmin)){
while($arrAdmin=$cms->db_fetch_array($rsAdmin))
{@extract($arrAdmin);	?>
	      <option value="<?=$city?>"><?=$city?></option> <?  
		}
		}
	   ?>
	  </select><?	
}


?>


 
