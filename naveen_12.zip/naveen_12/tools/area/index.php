<?php 
ob_start();
include("../../lib/opin.inc.php")?>
<?php define("CPAGE","category/")?>
<?php include("../inc/header.inc.php");?>
<div class="main">
<? include "../inc/header.php"; ?>
<div class="content">
<div class="div-tbl">
<div class="cl"></div>
 <?php $hedtitle = "Area Management"; ?>  
    <?=$adm->alert()?>
      <div class="title"  id="innertit">
       <?=$adm->heading(((!$mode)?'Area Manager':'Add/Update Category'))?>
        </div>
      <div class="tbl-contant"><?php if($mode){include("add.php");}else{include("manage.php");}?></div>
       <div class="cl"></div>
    </div>
  </div> 
<?php include("../inc/footer.inc.php")?></div>
</div>
<div class="cl"></div>
</div>
</div> 
</body>
</html>
<?php ob_end_flush();?>
