<div class="div-tbl">
        <div class="title">
          <div class="fl"><img src="images/form-icon.png" alt="">Forms</div>
          <div class="cl"></div>
        </div>
        <div class="tbl-contant">
          <div class="tbl-name">
            <h3  >Table Title</h3>
            <small>we can add some Discription here</small>
            <div class="cl"></div>
          </div>
          <div class="section">
            <label> Image<small>Products Image</small></label>
            <div>
              <div class="image-thm">
                <div class="tool"><a href="">View</a> <a href="">Delete</a></div>
                <a href=""  class="image"> <span></span><img src="images/img6.png" alt=""></a> </div>
              <div id="FileUpload">
                <input type="file" size="24" id="BrowserHidden" onchange="getElementById('FileField').value = getElementById('BrowserHidden').value;" />
                <div id="BrowserVisible">
                  <input type="text" id="FileField" />
                </div>
              </div>
              <span class="f_help"><span class="red">Error</span>Text custom help</span></div>
          </div>
          <div class="section">
            <label> full <small>Text custom</small></label>
            <div>
              <input type="text"  class="txt full">
              <span class="f_help"><span class="red">Error</span>Text custom help</span></div>
          </div>
          <div class="section">
            <label> Large <small>Text custom</small></label>
            <div>
              <input type="text" class="txt large">
              <span class="f_help"><span class="red">*</span>Text custom help</span></div>
          </div>
          <div class="section">
            <label> DropDown<small>Text custom</small></label>
            <div>
              <select name="select"  class="txt   select-txt">
                <option>-------Select Option------</option>
                <option>Option 1</option>
                <option>Option 1</option>
              </select>
              <span class="f_help">Text custom help</span></div>
          </div>
          <!-- <div class="section">
                                <label>Date picker</label>   
                                <div><input type="text" id="datepick" class="datepicker hasDatepicker" readonly="readonly" name="datepicker" size="10"><span class="ui-datepicker-append">(dd-mm-yyyy)</span></div>
                            </div> -->
          <div class="section">
            <label> Medium<small>Text custom</small></label>
            <div>
              <input type="text"  class="txt medium">
              <span class="f_help">Text custom help</span></div>
            <div>
              <input type="text"  class="txt medium">
              <span class="f_help">Text custom help</span></div>
          </div>
          <div class="section">
            <label> Small <small>Text custom</small></label>
            <div>
              <input type="text"  class="txt small">
              <span class="f_help">Text custom help</span></div>
          </div>
          <div class="section">
            <label> XSmall <small>Text custom</small></label>
            <div>
              <input type="text"  class="txt xxsmall">
              <span class="f_help">Text custom help</span></div>
          </div>
          <div class="section">
            <label> XSmall <small>Text custom</small></label>
            <div>
              <input type="text"  class="txt xxsmall"><input type="text"  class="txt xxsmall"><input type="text"  class="txt xxsmall">
              <span class="f_help">Text custom help</span></div>
          </div>
          <div class="section">
            <label> textarea <small>Elastic</small></label>
            <div>
              <textarea name="Textareaelastic" id="Textareaelastic" class="large" cols="" rows="" style="overflow: hidden; height: 73px; "></textarea>
              <span class="f_help">Text custom help</span></div>
          </div>
          <div class="section">
            <label> Radio <small>Text custom</small></label>
            <div>
               <span class="rdo"><input name="" type="radio" value="">Button Name</span>
               <span class="rdo"><input name="" type="radio" value="">Radio Name</span>
               <span class="rdo"><input name="" type="radio" value="">Radio Button</span>
                 <span class="rdo"><input name="" type="checkbox" value="">Button Name</span>
               <span class="rdo"><input name="" type="checkbox" value="">Radio Name</span>
               <span class="rdo"><input name="" type="checkbox" value="">Radio Button</span>
              <span class="f_help">Text custom help</span></div>
          </div>
          <div class="section last">
            <div>
              <input type="button" class="uibutton loading"  value="submit" >
              <input type="button" class="uibutton  special"  value="clear form"a>
            </div>
          </div>
        </div>
      </div>