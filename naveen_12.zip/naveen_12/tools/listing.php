<div class="div-tbl">
        <div class="title">
          <div class="fl"><img src="images/latest-icon.png" alt="">Latest 10 Orders </div>
          <div class="tbl-search">
            <input class="search-txt" value="Search" name="" type="text"   onclick="if(this.value=='Search'){this.value=''}" onblur="if(this.value==''){this.value='Search'}">
            <input type="image"   name="" src="images/search-icon.png" class="search-btn" >
            <div class="cl"></div>
          </div>
          <div class="cl"></div>
        </div>
        <div class="tbl-contant">
        
        <div class="alertMessage info SE" >information</div>
        <div class="alertMessage error SE"  >error();</div>
        <div class="alertMessage success SE">success</div>
        <div class="alertMessage warning SE" >warning !</div>
          <div class="tbl-name">
            <h3 class="fl">Table Title</h3>
            <select class="select-txt" name="">
              <option>10</option>
              <option>15</option>
              <option>25</option>
            </select>
            <div class="cl"></div>
          </div>
          <table width="100%"    cellpadding="0" cellspacing="0">
            <tr class="tbl-head">
              <td class="select-td"><input type="checkbox" name="checkbox" id="checkbox"></td>
              <td>Order ID</td>
              <td>Customer Name</td>
              <td>Order date</td>
              <td>Status</td>
              <td>Total</td>
              <td class="action-td">Action</td>
            </tr>
            <tr>
              <td><input type="checkbox" name="checkbox2" id="checkbox2"></td>
              <td>#2522<br></td>
              <td>Mr. White</td>
              <td>20-Sept-2012</td>
              <td>Panding</td>
              <td>$250</td>
              <td><a href="#"><img src="images/view-icon.png" alt=""></a><a href="#"><img src="images/delete-icon.png" alt=""></a></td>
            </tr>
            <tr>
              <td><input type="checkbox" name="checkbox3" id="checkbox3"></td>
              <td>#2321</td>
              <td>John Hill</td>
              <td>20-Sept-2012</td>
              <td>Panding</td>
              <td>$125</td>
              <td><a href="#"><img src="images/view-icon.png" alt=""></a><a href="#"><img src="images/delete-icon.png" alt=""></a></td>
            </tr>
            <tr>
              <td><input type="checkbox" name="checkbox4" id="checkbox4"></td>
              <td>#2522</td>
              <td>Mony Brown</td>
              <td>20-Sept-2012</td>
              <td>Panding</td>
              <td>$575</td>
              <td><a href="#"><img src="images/view-icon.png" alt=""></a><a href="#"><img src="images/delete-icon.png" alt=""></a></td>
            </tr>
            <tr>
              <td><input type="checkbox" name="checkbox5" id="checkbox5"></td>
              <td>#2522<br></td>
              <td>Mr. White</td>
              <td>20-Sept-2012</td>
              <td>Panding</td>
              <td>$250</td>
              <td><a href="#"><img src="images/view-icon.png" alt=""></a><a href="#"><img src="images/delete-icon.png" alt=""></a></td>
            </tr>
            <tr>
              <td><input type="checkbox" name="checkbox6" id="checkbox6"></td>
              <td>#2321</td>
              <td>John Hill</td>
              <td>20-June-2012</td>
              <td>Panding</td>
              <td>$125</td>
              <td><a href="#"><img src="images/view-icon.png" alt=""></a><a href="#"><img src="images/delete-icon.png" alt=""></a></td>
            </tr>
            <tr>
              <td><input type="checkbox" name="checkbox7" id="checkbox7"></td>
              <td>#2522</td>
              <td>Mony Brown</td>
              <td>20-Jan-2012</td>
              <td>Panding</td>
              <td>$575</td>
              <td><a href="#"><img src="images/view-icon.png" alt=""></a><a href="#"><img src="images/delete-icon.png" alt=""></a></td>
            </tr>
          </table>
           <div class="hr2"></div>
          <div class="pagination">
            <div class="total">Showing 1 to 15 of 15 entries</div>
            <div class="paging"> <a href="#">&laquo; Previeous</a> <a href="#" class="active">1</a> <a href="#">2</a> <a href="#">3</a> <a href="#">4</a> <a href="#">5</a> <a href="#">Next &raquo; </a> </div>
            <div class="cl"></div>
          </div>
        </div>
      </div>