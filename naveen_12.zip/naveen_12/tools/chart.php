<div class="div-tbl half">
        <div class="title"><img src="images/chart-icon.png" alt="">Chart</div>
        <div class="tbl-contant">
          <div id="TabbedPanels1" class="TabbedPanels">
            <ul class="TabbedPanelsTabGroup">
              <li class="TabbedPanelsTab" tabindex="0">LIVE CHART</li>
              <li class="TabbedPanelsTab" tabindex="0">PIE CHART</li>
            </ul>
            <div class="TabbedPanelsContentGroup">
              <div class="TabbedPanelsContent"><img src="images/chart.png" width="100%" alt=""></div>
              <div class="TabbedPanelsContent"> <!--Div that will hold the pie chart-->
                <div id="chart_div"></div>
              </div>
            </div>
          </div>
        </div>
      </div>