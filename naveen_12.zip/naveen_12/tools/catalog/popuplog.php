<?php include("../../lib/opin.inc.php")?>
<?php define("CPAGE","catalog/")?>
<?php include("../inc/header.inc.php")?>
<?php   
	if($cms->is_post_back()){
		if($arr_ids) {
			$str_adm_ids = implode(",",$arr_ids);
			switch ($_POST['action']){
				case "delete":
					$cms->db_query("delete from #_popup_count where pid in ($str_adm_ids)");
					$adm->sessset(count($arr_ids).' Item(s) Delete', 'e');
					break; 
				default:
			}
		}
		$cms->redir(SITE_PATH_ADM.CPAGE."/manage-store.php", true);
		exit;
	}  
	$start = intval($start);    
	$pagesize = intval($pagesize)==0?$pagesize=DEF_PAGE_SIZE:$pagesize; 
	$columns = "select * ";
	$sql = " from #_popup_count where compagin_id = '$cid'  $cond  ";
	$order_by == '' ? $order_by = '(pid)' : true;
	$order_by2 == '' ? $order_by2 = 'desc' : true;
	$sql_count = "select count(*) ".$sql; 
	$sql .= "order by $order_by $order_by2 ";
	$sql .= "limit $start, $pagesize ";
	$sql = $columns.$sql;
	$result = $cms->db_query($sql);
	$reccnt = $cms->db_scalar($sql_count);
?>
<div class="main">
<header>
     
      <div class="hrd-right-wrap">  
        
        <div class="brdcm" id="hed-tit">Pop Up Log</div>
        <div class="unvrl-btn">   
        <a href="javascript:void(0)" onclick="javascript:formback();" class="ub">
        <img src="<?=SITE_PATH_ADM?>images/back.png" alt=""></a> 
        
        </div> 
      </div>
      <div class="cl"></div>
    </header> 
    
 <div class="cl"></div>
<div class="content">
<div class="div-tbl">
<div class="cl"></div>
    <? //$adm->h1_tag('Dashboard &rsaquo; Collection Manager',$others)?>
   
<?php $hedtitle = "Pop Up Log Detail"; ?>    
      <?=$adm->alert()?>
      <div class="title"  id="innertit">
        <?=$adm->heading('Pop Up Log')?>
      </div>
      <div class="tbl-contant">
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0"  class="data-tbl">
           <tr class="t-hdr">
			  <td width="6%" align="center"><?=$adm->orders('#',false)?></td>
			  <td width="6%" align="center" valign="middle"><?=$adm->check_all()?></td>
			  <td width="25%" align="center"><?=$adm->orders('Compain Name',true)?></td> 
			  <td width="15%" align="center"><?=$adm->orders('Cookie',true)?></td> 
			  <td width="10%" align="center"><?=$adm->orders('Time',true)?></td>  
			</tr>
			<?php if($reccnt){ $nums=1; while ($line = $cms->db_fetch_array($result)){@extract($line);?>
			<tr <?=$adm->even_odd($nums)?>>
			<td align="center"><?=$nums?></td>
			<td align="center"><?=$adm->check_input($pid)?></td>
			<td align="center"><?=$cms->getSingleresult("select name from #_compagin where pid  = '$compagin_id'")?></td>
			<td align="center"><?=$cms->getSingleresult("select name from #_cookie where pid  = '$cookie_id'")?></td>
			<td align="center" class="<?=strtolower($status)?>"><?=$popup_time?></td>
			 
			</tr>
          <?php $nums++;}}else{ echo $adm->rowerror(5);}?>
        </table>
      </div>
	   <?php include("../inc/paging.inc.php")?>
    </div>
<?php include("../inc/footer.inc.php")?>
</div>
<div class="cl"></div>
</div>
</div>
</body>
</html>
