<?php include("../../lib/opin.inc.php")?>
<?php define("CPAGE","gallery/")?>
<?php include("../inc/header.inc.php");?>
<div class="main">
<? include "../inc/header2.php"; ?>
<div class="content">
<div class="div-tbl">
<div class="cl"></div>
	 
<?php $hedtitle = "Page Management"; ?>  
    <?=$adm->alert()?>
      <div class="title" id="innertit">
           <?=$adm->heading(((!$mode)?'Page Manager':'Update Meta Info'))?>
        </div>
      <div class="tbl-contant" ><?php if($mode){include("add.php");}else{include("manage.php");}?></div>
       <div class="cl"></div>
    </div>
  </div> 
<?php include("../inc/footer.inc.php")?></div>
</div>
<div class="cl"></div>
</div>
</div>

<script type="text/javascript">
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
var Accordion1 = new Spry.Widget.Accordion("Accordion1");
$(document).ready(function(){
	alert('sss');
	//$("#hed-tit").html()="abcbcb";
	
	});
</script>
</body>
</html>
