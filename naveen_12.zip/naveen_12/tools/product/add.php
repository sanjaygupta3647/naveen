<?php defined('_JEXEC') or die('Restricted access'); error_reporting(E_ERROR | E_PARSE); ?>
 
<?php  
if($cms->is_post_back()){  
	if($_POST[dofferprice]>$_POST[dprice]){ 
		$adm->sessset('Offer price Can not Greater Than The Price.', 's');
		$cms->redir($path, true);
	} 
	if($updateid){ 
		$cms->sqlquery("rs","product",$_POST,'pid',$updateid); 
		if($_POST[image_name]){
			foreach($_POST[image_name] as $val){
				$query="update #_prod_images set image_name=  '".$val."' where prod_id='$updateid' "; 
				$cms->db_query($query);
			} 
		} 
		foreach(array_combine($_POST[specification],$_POST[speci_id]) as $key=>$value){
		     
				$query="update #_prod_specification set specification='".$key."' where prod_id='$updateid' and pid='".$value."' ";
				$cms->db_query($query);
			 
	    } 
		$adm->sessset('Record has been updated', 's'); 
		 
	}else{
		$_POST[submitdate] = time();
		$cms->sqlquery("rs","product",$_POST);
		$updateid = mysql_insert_id(); 
		foreach($_POST[specification] as $val){ 
				$query="insert into #_prod_specification set specification=  '".$val."', prod_id='$updateid' ";
				$cms->db_query($query);
			  }	 
		$adm->sessset('Record has been added', 's'); 
		 
		
	}  
 	 
		
$cms->redir(SITE_PATH_ADM.CPAGE, true);
}


	     

        
if(isset($id)){
	$rsAdmin=$cms->db_query("select * from #_product where pid='".$id."'");
	$arrAdmin=$cms->db_fetch_array($rsAdmin);
	@extract($arrAdmin);
	}
?>   
 
 <table width="100%" border="0" align="left" cellpadding="4" cellspacing="1" class="frm-tbl2">
    <form enctype="multipart/form-data" action="" method="post"> 
     <tr id="subcat">
      <td width="25%"  class="label">Category:</td>
      <td width="75%">
		 <select name="parentId" class="txt">
          
          <?php $rsAdmin_=$cms->db_query("select pid,name from #_category where `status`='Active' and `parentId`='0' order by name ");
	 		 while($arrAdmin_=$cms->db_fetch_array($rsAdmin_)){ ?>
			 <optgroup label="<?=$arrAdmin_[name]?>"><?php
			  $subcat=$cms->db_query("select pid,name from #_category where `status`='Active' and `parentId`='".$arrAdmin_[pid]."' order by name ");
			  if(mysql_num_rows($subcat)){
	 		    while($rs=$cms->db_fetch_array($subcat)){?>
				<option value="<?=$arrAdmin_[pid]?>" <?=(($cat_id==$rs[pid])?'selected="selected"':'')?>>
				 <?=$rs[name]?>
				 <?php
				}
			  }?>
			  </option>
		    </optgroup>  
          <?php  } ?>
        </select>
	  </td>
    </tr>  
    
     
    <tr>
      <td width="25%"  class="label">Name:</td>
      <td width="75%"><input type="text" name="title"  lang="R" title="Name" class="txt medium"value="<?=$title?>" />
	  </td>

	    </tr>
	 <tr  class="grey_">
      <td width="25%" valign="top" class="label">Short title:</td>
      <td width="75%"><textarea name="short_title" cols="80" rows="5" id="Short title"><?=$short_title?></textarea></td>
    </tr>
    </tr>
	 <tr  class="grey_">
      <td width="25%" valign="top" class="label">Meta title:</td>
      <td width="75%"><textarea name="meta_title" cols="80" rows="5" id="meta_title"><?=$meta_title?></textarea></td>
    </tr>
    
   <tr>
      <td width="25%" valign="top"  class="label">Meta keywords :</td>
      <td width="75%"><textarea name="meta_keyword" cols="80" rows="5" id="meta_keyword"><?=$meta_keyword?></textarea></td>
    </tr>
	<tr  class="grey_">
	  <td valign="top" class="label">Meta description :</td> 
	  <td><textarea name="meta_description" cols="80" rows="5" id="meta_description"><?=$meta_description?></textarea></td>
    </tr> 
	 

	<tr>
      <td width="25%"  class="label">Price</td>
      <td width="75%"><input type="text" name="price" title="Price" class="txt medium" value="<?=$price?>" /></td>
    </tr>
	<tr>
	<tr>
      <td width="25%"  class="label">Offer Price</td>
      <td width="75%"><input type="text" name="offer_price" title="Order" class="txt medium" value="<?=$offer_price?>" /></td>
    </tr>
	
	<tr>
      <td width="25%"  class="label">State Name:</td>
      <td width="75%"><select name="state" lang="R" title="State" class="txt" id="state_id"> 
	     <option > ----Select State---- </option>
	      <option value="Uttar Pradesh"<?=($state=='Uttar Pradesh')?'selected="selected"':''?>>Uttar Pradesh </option>
          <option value="Maharashtra"<?=($state=='Maharashtra')?'selected="selected"':''?>> Maharashtra</option>
          <option value="Bihar"<?=($state=='Bihar')?'selected="selected"':''?>>Bihar</option>
          <option value="West Bengal"<?=($state=='West Bengal')?'selected="selected"':''?>>West Bengal</option>
          <option value="Andhra Pradesh"<?=($state=='Andhra Pradesh')?'selected="selected"':''?>>Andhra Pradesh</option>
          <option value="Madhya Pradesh"<?=($state=='Madhya Pradesh')?'selected="selected"':''?>>Madhya Pradesh</option>
          <option value="Tamil Nadu"<?=($state=='Tamil Nadu')?'selected="selected"':''?>>Tamil Nadu</option>
          <option value="Rajasthan"<?=($state=='Rajasthan')?'selected="selected"':''?>>Rajasthan</option>
          <option value="Karnataka"<?=($state=='Karnataka')?'selected="selected"':''?>>Karnataka</option>
		  <option value="Gujarat<?=($state=='Gujarat')?'selected="selected"':''?>">Gujarat</option>
		  <option value="Odisha"<?=($state=='Odisha')?'selected="selected"':''?>>Odisha</option>
		  <option value="Kerala"<?=($state=='Kerala')?'selected="selected"':''?>>Kerala</option>
		  <option value="Jharkhand"<?=($state=='Jharkhand')?'selected="selected"':''?>>Jharkhand</option>
		  <option value="Assam"<?=($state=='Assam')?'selected="selected"':''?>>Assam</option>
		  <option value="Punjab"<?=($state=='Punjab')?'selected="selected"':''?>>Punjab</option>
		  <option value="Chhattisgarh"<?=($state=='Chhattisgarh')?'selected="selected"':''?>> Chhattisgarh</option>
		  <option value="Haryana"<?=($state=='Haryana')?'selected="selected"':''?>>Haryana</option>
		  <option value="Jammu and Kashmir"<?=($state=='Jammu and Kashmir')?'selected="selected"':''?>>Jammu and Kashmir</option>
		  <option value="Uttarakhand"<?=($state=='Uttarakhand')?'selected="selected"':''?>>Uttarakhand</option>
		  <option value="Himachal Pradesh"<?=($state=='Himachal Pradesh')?'selected="selected"':''?>>Himachal Pradesh</option>
		  <option value="Tripura"<?=($state=='Tripura')?'selected="selected"':''?>>Tripura</option>
		  <option value="Meghalaya"<?=($state=='Meghalaya')?'selected="selected"':''?>>Meghalaya</option>
		  <option value="Manipur"<?=($state=='Manipur')?'selected="selected"':''?>>Manipur</option>
		  <option value="Nagaland"<?=($state=='Maharashtra')?'selected="selected"':''?>>Nagaland</option>
		  <option value="Goa"<?=($state=='Goa')?'selected="selected"':''?>>Goa</option>
		  <option value="Arunachal Pradesh"<?=($state=='Arunachal Pradesh')?'selected="selected"':''?>>Arunachal Pradesh</option>
		  <option value="Mizoram"<?=($state=='Mizoram')?'selected="selected"':''?>>Mizoram</option>
		  <option value="Sikkim"<?=($state=='Sikkim')?'selected="selected"':''?>>Sikkim</option>
		  <option value="Delhi"<?=($state=='Delhi')?'selected="selected"':''?>>Delhi</option>
		  <option value="Puducherry"<?=($state=='Puducherry')?'selected="selected"':''?>>Puducherry</option>
		  <option value="Chandigarh"<?=($state=='Chandigarh')?'selected="selected"':''?>>Chandigarh</option>
		  <option value="Andaman and Nicobar Islands"<?=($state=='Andaman and Nicobar Islands')?'selected="selected"':''?>>Andaman and Nicobar Islands</option>
		  <option value="Dadra and Nagar Haveli"<?=($state=='Dadra and Nagar Haveli')?'selected="selected"':''?>>Dadra and Nagar Haveli</option>
		  <option value="Daman and Diu"<?=($state=='Daman and Diu')?'selected="selected"':''?>>Daman and Diu</option>
		  <option value="Lakshadweep"<?=($state=='Lakshadweep')?'selected="selected"':''?>> Lakshadweep</option>
		 </select>
        </td>
    </tr> 
	
     
	<tr>
	<tr> 
      <td width="25%"  class="label">Ciry</td>
      <td width="75%">  
	  <span id="ajaxDiv"> 
       <select name="city" title="city" class="select txt" lang="R"> 
      <? $rsAdmin=$cms->db_query("select pid,city from #_state where state='$state'");
	  while($arrAdmin=$cms->db_fetch_array($rsAdmin)){@extract($arrAdmin);
	  ?>
	  <option value="<?=$city?>" <?=(($city==$city )?'selected="selected"':'')?>><?=$city?></option> 
       <?
	   }?>
	    </select>	
	   </span>
	  
	  </td>
    </tr>
	<tr>
      <td width="25%"  class="label">Area</td>
      <td width="75%"> 
	   <span id="ajaxDiv"> 
       <select name="area" title="Area" class="select txt"  lang="R"> 
      <? $rsAdmin=$cms->db_query("select pid,city from #_area where city='$city'");
	  while($arrAdmin=$cms->db_fetch_array($rsAdmin)){@extract($arrAdmin);
	  ?>
	  <option value="<?=$area?>" <?=(($area==$area )?'selected="selected"':'')?>><?=$area?></option> 
       <?
	   }?>
	  </select>	
	   </span>
	  
	  </td>
    </tr>
	
	
    <?php if($image1  and is_file($_SERVER['DOCUMENT_ROOT'].SITE_SUB_PATH."uploaded_files/orginal/".$image1)==true){?>
          <tr>
            <td valign="top" class="label">&nbsp;</td>
            <td valign="top"><img src="<?=SITE_PATH?>uploaded_files/orginal/<?=$image1?>" width="100"> &nbsp;&nbsp;
            </td>
          </tr>
          <?php } ?>
          <tr>
            <td valign="top" class="label">Image1:</td>
            <td valign="top"> <input type="text" name="image1" value="<?=$image1?>" class="txt medium" id="upimg" />
         <img onClick="window.open('<?=SITE_PATH_ADM."crop/imageupload.php?imgid=upimg&image=product&view=big&name=".$image1?>','mywindow','width=900,height=400,left=200,scrollbars=yes, top=100,screenX=0,screenY=100')" src="<?=SITE_PATH_ADM?>images/clickhere.png" alt="" class="img-click" /> <br /></td>
          </tr>
          
        <?php if($image2 and $id and is_file($_SERVER['DOCUMENT_ROOT'].SITE_SUB_PATH."uploaded_files/orginal/".$image2)==true){?>
          <tr>
            <td valign="top" class="label">&nbsp;</td>
            <td valign="top"><img src="<?=SITE_PATH?>uploaded_files/orginal/<?=$image2?>" width="100"> &nbsp;&nbsp;
            </td>
          </tr>
          <?php } ?>
          <tr>
            <td valign="top" class="label">Image2:</td>
            <td valign="top"> <input type="text" name="image2" value="<?=$image2?>" class="txt medium" id="upimg2" />
       <img onClick="window.open('<?=SITE_PATH_ADM."crop/imageupload.php?imgid=upimg2&image=product&view=big&name=".$pimage?>','mywindow','width=900,height=400,left=200,scrollbars=yes, top=100,screenX=0,screenY=100')" src="<?=SITE_PATH_ADM?>images/clickhere.png" alt="" class="img-click" /> <br /></td>
          </tr>
          
          
       <?php if($image3  and is_file($_SERVER['DOCUMENT_ROOT'].SITE_SUB_PATH."uploaded_files/orginal/".$image3)==true){?>
          <tr>
            <td valign="top" class="label">&nbsp;</td>
            <td valign="top"><img src="<?=SITE_PATH?>uploaded_files/orginal/<?=$image3?>" width="100"> &nbsp;&nbsp;
            </td>
          </tr>
          <?php } ?>
          <tr>
            <td valign="top" class="label">Image3:</td>
            <td valign="top"> <input type="text" name="image3" value="<?=$image3?>" class="txt medium" id="upimg3" />
       <img onClick="window.open('<?=SITE_PATH_ADM."crop/imageupload.php?imgid=upimg3&image=product&view=big&name=".$pimage?>','mywindow','width=900,height=400,left=200,scrollbars=yes, top=100,screenX=0,screenY=100')" src="<?=SITE_PATH_ADM?>images/clickhere.png" alt="" class="img-click" /> <br /></td>
          </tr>
           
       <?php if($image4  and is_file($_SERVER['DOCUMENT_ROOT'].SITE_SUB_PATH."uploaded_files/orginal/".$image4)==true){?>
          <tr>
            <td valign="top" class="label">&nbsp;</td>
            <td valign="top"><img src="<?=SITE_PATH?>uploaded_files/orginal/<?=$image4?>" width="100"> &nbsp;&nbsp;
            </td>
          </tr>
          <?php } ?>
          <tr>
            <td valign="top" class="label">Image4:</td>
            <td valign="top"> <input type="text" name="image4" value="<?=$image4?>" class="txt medium" id="upimg4" />
       <img onClick="window.open('<?=SITE_PATH_ADM."crop/imageupload.php?imgid=upimg4&image=product&view=big&name=".$pimage?>','mywindow','width=900,height=400,left=200,scrollbars=yes, top=100,screenX=0,screenY=100')" src="<?=SITE_PATH_ADM?>images/clickhere.png" alt="" class="img-click" /> <br /></td>
          </tr>       
		  
    <?php if($image5  and is_file($_SERVER['DOCUMENT_ROOT'].SITE_SUB_PATH."uploaded_files/orginal/".$image5)==true){?>
          <tr>
            <td valign="top" class="label">&nbsp;</td>
            <td valign="top"><img src="<?=SITE_PATH?>uploaded_files/orginal/<?=$image5?>" width="100"> &nbsp;&nbsp;
            </td>
          </tr>
          <?php } ?>
          <tr>
            <td valign="top" class="label">Image5:</td>
            <td valign="top"> <input type="text" name="image5" value="<?=$image5?>" class="txt medium" id="upimg5" />
       <img onClick="window.open('<?=SITE_PATH_ADM."crop/imageupload.php?imgid=upimg5&image=product&view=thumb&name=".$image?>','mywindow','width=900,height=400,left=200,scrollbars=yes, top=100,screenX=0,screenY=100')" src="<?=SITE_PATH_ADM?>images/clickhere.png" alt=""  class="img-click" /> <br /></td>
          </tr>
          
        <?php if($image6 and $id and is_file($_SERVER['DOCUMENT_ROOT'].SITE_SUB_PATH."uploaded_files/orginal/".$image6)==true){?>
          <tr>
            <td valign="top" class="label">&nbsp;</td>
            <td valign="top"><img src="<?=SITE_PATH?>uploaded_files/orginal/<?=$image6?>" width="100"> &nbsp;&nbsp;
            </td>
          </tr>
          <?php } ?>
          <tr>
            <td valign="top" class="label">Image6:</td>
            <td valign="top"> <input type="text" name="image6" value="<?=$image6?>" class="txt medium" id="upimg6" />
       <img onClick="window.open('<?=SITE_PATH_ADM."crop/imageupload.php?imgid=upimg6&image=product&view=big&name=".$pimage?>','mywindow','width=900,height=400,left=200,scrollbars=yes, top=100,screenX=0,screenY=100')" src="<?=SITE_PATH_ADM?>images/clickhere.png" alt="" class="img-click" /> <br /></td>
          </tr>
          
          
       <?php if($image7  and is_file($_SERVER['DOCUMENT_ROOT'].SITE_SUB_PATH."uploaded_files/orginal/".$image7)==true){?>
          <tr>
            <td valign="top" class="label">&nbsp;</td>
            <td valign="top"><img src="<?=SITE_PATH?>uploaded_files/orginal/<?=$image7?>" width="100"> &nbsp;&nbsp;
            </td>
          </tr>
          <?php } ?>
          <tr>
            <td valign="top" class="label">Image7:</td>
            <td valign="top"> <input type="text" name="image7" value="<?=$image7?>" class="txt medium" id="upimg7" />
       <img onClick="window.open('<?=SITE_PATH_ADM."crop/imageupload.php?imgid=upimg7&image=product&view=big&name=".$pimage?>','mywindow','width=900,height=400,left=200,scrollbars=yes, top=100,screenX=0,screenY=100')" src="<?=SITE_PATH_ADM?>images/clickhere.png" alt="" class="img-click" /> <br /></td>
          </tr>
           
       <?php if($image8  and is_file($_SERVER['DOCUMENT_ROOT'].SITE_SUB_PATH."uploaded_files/orginal/".$image8)==true){?>
          <tr>
            <td valign="top" class="label">&nbsp;</td>
            <td valign="top"><img src="<?=SITE_PATH?>uploaded_files/orginal/<?=$image8?>" width="100"> &nbsp;&nbsp;
            </td>
          </tr>
          <?php } ?>
          <tr>
            <td valign="top" class="label">Image8:</td>
            <td valign="top"> <input type="text" name="image8" value="<?=$image8?>" class="txt medium" id="upimg8" />
       <img onClick="window.open('<?=SITE_PATH_ADM."crop/imageupload.php?imgid=upimg8&image=product&view=big&name=".$pimage?>','mywindow','width=900,height=400,left=200,scrollbars=yes, top=100,screenX=0,screenY=100')" src="<?=SITE_PATH_ADM?>images/clickhere.png" alt="" class="img-click" /> <br /></td>
          </tr>       
	<tr>
      <td width="25%"  class="label">Product Specifications</td>
      <td width="75%">
	  <?php 
			 
			$qry2 = $cms->db_query("select * from #_prod_specification where prod_id='".$id."'");
			if(mysql_num_rows($qry2)){
			    while($res1 = $cms->db_fetch_array($qry2)){ extract($res1);?> 
	  <input type="text" name="specification[]" title="Specification" value="<?=$specification?>" class="txt medium" /><br /><br />
	  <input type="hidden" name="speci_id[]" value="<?=$pid?>"  />
	  <?php }  }else{ ?>
	    <input type="text" name="specification[]" title="Specification" value="<?=$specification?>" class="txt medium" /><br /><br />  
	  <?php } ?>
	  <div id="addinput"> </div>
              <p style="margin-left:885px; cursor:pointer" title="Add More" id="addNew"><strong>Add More</strong></p> 
	  </td>
    </tr>

	<tr>
	  <td valign="top" class="label">&nbsp;</td>
	  <td valign="top">&nbsp;</td>
    </tr>
	
	
	
	<tr>
	  <td valign="top" class="label">Full Description:</td>
	  <td valign="top">
      <?=$adm->get_editor('description', stripslashes($description))?> 
      </td>
	</tr>  
   
	<tr>
	  <td class="label">Status:<span>*</span></td>
	  <td><select name="status" class="txt medium" lang="R" title="Status">
	  <option value="Active" <?=(($status=='Active')?'selected="selected"':'')?>>Active</option>
	  <option value="Inactive" <?=(($status=='Inactive')?'selected="selected"':'')?>>Inactive</option>
	  </select>	  </td>
    </tr>

	
    
	<tr>
	  <td>&nbsp;</td>
	  <td>
	  <input type="submit" name="Submit" class="uibutton  loading" value="&nbsp;&nbsp;&nbsp;Submit&nbsp;&nbsp;&nbsp;"  />  </td>
    </tr>	
  </table> 
  
  <script type="text/javascript">
  $(function() {
	var addDiv = $('#addinput');
	var i = $('#addinput p').size() + 1;
	$('#addNew').live('click', function() {
		$('<p id="'+i+'"><?=$dcont?><input type="text" name="specification[]" title="Specification" class="txt medium" value="" />  <a href="#" lang="'+i+'" class="remNew">Remove</a></p>').appendTo(addDiv);
		i++;
		return false;
	});
	$('.remNew').live('click', function() {
		var ggetid = $(this).attr('lang');
		$("#"+ggetid).remove();
		 
			if( i > 1 ) {
				$(this).parents('p').remove();
				i--;
			} 
			return false;  
	  });
	$(".view_more").click(function(){
	 
	var last  = $(this).attr("title"); 
	var show  = 3;
	var next =  +last+ +show; 
	 
	for(var i =last; i<=next;i++ ) {
		$("#hd"+i).show();
		$("#cm"+i).show();
	}
	$(this).attr("title",next);
});
}); 
  
  </script>
  
 <script type="text/javascript"> 
 function addField(){
  var newContent = '<br /><input type="text" name="image_name[]" value="" class="txt medium" id="upimg3" />';
      newContent += <img onClick="window.open('<?=SITE_PATH_ADM."crop/imageupload.php?imgid=upimg3&image=product&view=big&name=".$pimage?>','mywindow','width=900,height=400,left=200,scrollbars=yes, top=100,screenX=0,screenY=100')" src="<?=SITE_PATH_ADM?>images/clickhere.png" alt="" class="img-click" /> <br />;
	 
  $(".addmore").append(newContent); 
 }
</script>
<script type="text/javascript"> 
 function addField1(){
  var newContent = '<br /><input type="text" name="specification[]" title="Specification" class="txt medium" value="" /><br />'; 
  $(".addmore1").append(newContent); 
 }
</script>

<script type="text/javascript">
	<?php if(!$cont){ ?>  addField1(); <?php }?>
    $(document).ready(function(){ 
	 $( "table" ).delegate( ".delmulty", "click", function() {
		$(this).parent().remove()
	 }); 
  }); 
  </script>
  
   <script type="text/javascript">
		 		$("#state_id").change(function(){
 					var state = $(this).val();
						$.ajax({ 
						url: '<?=SITE_PATH_ADM.CPAGE?>/ajax-city.php?state='+state, 
						success: function (data) {
							$("#ajaxDiv").html(data); 
						},
						error: function (request, status, error) {
						alert(request.responseText);
						}
						});  
					}); 
					 
 </script>
 
 
