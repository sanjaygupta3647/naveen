<div class="div-tbl">
        <div class="title">
          <div class="fl"><img src="images/gallery-ico.png" alt="">Album Gallery </div>
          <div class="tbl-search">
            <input class="search-txt" value="Search" name="" type="text"   onclick="if(this.value=='Search'){this.value=''}" onblur="if(this.value==''){this.value='Search'}">
            <input type="image"   name="" src="images/search-icon.png" class="search-btn" >
            <div class="cl"></div>
          </div>
          <div class="cl"></div>
        </div>
        <div class="tbl-contant">
          <div class="tbl-name">
            <h3 class="fl">Albums Thumbs</h3>
            <select class="select-txt" name="">
              <option>10</option>
              <option>15</option>
              <option>25</option>
            </select>
            <div class="cl"></div>
          </div>
          <div class="albm-gallery">
            <div class="albm">
               <a href="" class="image"><span></span><img src="images/img6.png" alt=""></a> 
              <div class="date">02/20/2012</div>
              <div class="status">IMAGES: 10</div>
            </div>
            <div class="albm">
              <a href="" class="image"><span></span><img src="images/img2.png" alt=""></a> 
              <div class="date">02/20/2012</div>
              <div class="status">IMAGES: 10</div>
            </div>
            <div class="albm">
              <a href="" class="image"><span></span><img src="images/thm.png" alt=""></a> 
              <div class="date">02/20/2012</div>
              <div class="status">IMAGES: 10</div>
            </div>
            <div class="albm">
              <a href="" class="image"><span></span><img src="images/img6.png" alt=""></a> 
              <div class="date">02/20/2012</div>
              <div class="status">IMAGES: 10</div>
            </div>
            <div class="albm">
              <a href="" class="image"><span></span> </a> 
              <div class="date">02/20/2012</div>
              <div class="status">IMAGES: 10</div>
            </div> <div class="albm">
              <a href="" class="image"><span></span><img src="images/img2.png" alt=""></a> 
              <div class="date">02/20/2012</div>
              <div class="status">IMAGES: 10</div>
            </div>
            <div class="albm">
              <a href="" class="image"><span></span><img src="images/thm.png" alt=""></a> 
              <div class="date">02/20/2012</div>
              <div class="status">IMAGES: 10</div>
            </div>
            <div class="albm">
              <a href="" class="image"><span></span><img src="images/img6.png" alt=""></a> 
              <div class="date">02/20/2012</div>
              <div class="status">IMAGES: 10</div>
            </div>
            <div class="albm">
              <a href="" class="image"><span></span></a> 
              <div class="date">02/20/2012</div>
              <div class="status">IMAGES: 10</div>
            </div> <div class="albm">
              <a href="" class="image"><span></span><img src="images/img2.png" alt=""></a> 
              <div class="date">02/20/2012</div>
              <div class="status">IMAGES: 10</div>
            </div>
            <div class="albm">
              <a href="" class="image"><span></span><img src="images/thm.png" alt=""></a> 
              <div class="date">02/20/2012</div>
              <div class="status">IMAGES: 10</div>
            </div>
            <div class="albm">
              <a href="" class="image"><span></span><img src="images/img6.png" alt=""></a> 
              <div class="date">02/20/2012</div>
              <div class="status">IMAGES: 10</div>
            </div>
            <div class="albm">
              <a href="" class="image"><span></span> </a> 
              <div class="date">02/20/2012</div>
              <div class="status">IMAGES: 10</div>
            </div>
<div class="cl"></div>
          </div>
          
          <div class="hr2"></div>
            <div class="tbl-name">
            <h3 class="fl">Images Thumbs</h3>
             
            <div class="cl"></div>
          </div>
          <div class="image-gallery">
            <div class="image-thm">
            <div class="tool"><a href="">View</a> <a href="">Edit</a> <a href="">Delete</a></div>
               <a href=""  class="image"> <span></span> </a> 
              <div class="status">IMAGES NAME</div>
            </div>
            
            <div class="image-thm">
            <div class="tool"><a href="">View</a> <a href="">Edit</a> <a href="">Delete</a></div>
               <a href=""  class="image"> <span></span><img src="images/thm.png" alt=""></a> 
              <div class="status">IMAGES NAME</div>
            </div>
            
            <div class="image-thm">
            <div class="tool"><a href="">View</a> <a href="">Edit</a> <a href="">Delete</a></div>
               <a href=""  class="image"> <span></span><img src="images/img6.png" alt=""></a> 
              <div class="status">IMAGES NAME</div>
            </div>
            
            <div class="image-thm">
            <div class="tool"><a href="">View</a> <a href="">Edit</a> <a href="">Delete</a></div>
               <a href=""  class="image"> <span></span><img src="images/img2.png" alt=""></a> 
              <div class="status">IMAGES NAME</div>
            </div>
            
            <div class="image-thm">
            <div class="tool"><a href="">View</a> <a href="">Edit</a> <a href="">Delete</a></div>
               <a href=""  class="image"> <span></span><img src="images/thm.png" alt=""></a> 
              <div class="status">IMAGES NAME</div>
            </div>
            
            <div class="image-thm">
            <div class="tool"><a href="">View</a> <a href="">Edit</a> <a href="">Delete</a></div>
               <a href=""  class="image"> <span></span><img src="images/img6.png" alt=""></a> 
              <div class="status">IMAGES NAME</div>
            </div>
            
            <div class="image-thm">
            <div class="tool"><a href="">View</a> <a href="">Edit</a> <a href="">Delete</a></div>
               <a href=""  class="image"> <span></span><img src="images/img2.png" alt=""></a> 
              <div class="status">IMAGES NAME</div>
            </div>
            
            <div class="image-thm">
            <div class="tool"><a href="">View</a> <a href="">Edit</a> <a href="">Delete</a></div>
               <a href=""  class="image"> <span></span></a> 
              <div class="status">IMAGES NAME</div>
            </div>
            
            <div class="image-thm">
            <div class="tool"><a href="">View</a> <a href="">Edit</a> <a href="">Delete</a></div>
               <a href=""  class="image"> <span></span><img src="images/thm.png" alt=""></a> 
              <div class="status">IMAGES NAME</div>
            </div>
            
            <div class="image-thm">
            <div class="tool"><a href="">View</a> <a href="">Edit</a> <a href="">Delete</a></div>
               <a href=""  class="image"> <span></span><img src="images/img6.png" alt=""></a> 
              <div class="status">IMAGES NAME</div>
            </div>
             
              
<div class="cl"></div>
          </div>
          <div class="pagination">
            <div class="total">Showing 1 to 15 of 15 entries</div>
            <div class="paging"> <a href="#">&laquo; Previeous</a> <a href="#" class="active">1</a> <a href="#">2</a> <a href="#">3</a> <a href="#">4</a> <a href="#">5</a> <a href="#">Next &raquo; </a> </div>
            <div class="cl"></div>
          </div>
        </div>
      </div>