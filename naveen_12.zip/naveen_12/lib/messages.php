<?php 
	#admin msg
	$msg[0] = "Username and password is incorrect.";
	
	$msg[1] = "Invalid email id.";
	
	$msg[2] = "Password has been sent to your emnail id.";
?>