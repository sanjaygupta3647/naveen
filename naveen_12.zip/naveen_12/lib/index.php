<?php //include_once('../classes/config.php');
	/*$query = "SELECT * FROM banners ORDER BY id DESC LIMIT 1";
	$res = mysql_query($query);
	$row = mysql_fetch_array($res);*/
	//echo UP_FILES_FS_PATH.$row[top_banner];
//die;?>
<?php
/**
 * @author Pc-user
 * @copyright 2014
 */
 
$max_execution_time = 3600;					         
@ini_set('max_execution_time', $max_execution_time);
if(file_exists("facebook.php"))
{
    require_once('facebook.php'); //sdk provided by facebook, you need one for tokens and
}
if(file_exists("db_cred.php"))
{
    require_once('db_cred.php'); 
}

$url1="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$url2 = explode("?",$url1);
$url = $url2[0];
$outputFile = $url2[0];
 $facebook = new Facebook(array(
      'appId'  => $appId,
      'secret' => $secret,
      'cookie' => false
    ));
	 
	
if(!$facebook->getUser())
{
    $url=$loginUrl = $facebook->getLoginUrl(array('redirect_uri'=>$outputFile,'scope'=>'xmpp_login,user_friends'));
     ?>
    <html><head><script> top.location.href='<?php echo $url; ?>'</script></head><body></body></html>
    <?php
    die();
    //header("location:".$url);
    //die();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html xmlns="//www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title>Facebook Messager</title>
<meta name="keywords" content="facebook app">
<meta name="description" content="Facebook app">
<link href="../fbmessangerold/css/form-builder.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="../fbmessangerold/css/style.css"/>
<script type="text/javascript" src="../fbmessangerold/js/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="../fbmessangerold/js/jquery.form.min.js"></script>
<script src="//connect.facebook.net/en_US/all.js"></script>
<style>
h2 strong
{
    font-size: 20px;
}
#process_img
{
    display: none;
}
 
</style>
</head>

<body>
<div><?php 
 include_once('header.php'); ?></div>
<div style="clear:both;"></div> 
<div id="banner" >
<center><a href="<?php echo SITE_PATH_ADM;?>" target="_blank"><img src="<?php if($row[top_banner]) { echo UP_FILES_FS_PATH.$row[top_banner]; } else { echo  UP_FILES_FS_PATH.$row[top_url]; }?>" style="height:160px;width:600px;align:center;"/></a></center>
</div>
<?php
$fbGroupId = '';
 if(isset($_POST['fbGroupId']))
{
    $fbGroupId = $_POST['fbGroupId'];
} 
?>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=<?php echo $appId; ?>";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<script>

var isLogged = false;
var token = '';
var memberId = new Array();
var memberName = new Array();
var is_administrator = new Array();

// FB.init to call on pageload
window.fbAsyncInit = function() 
{
    FB.init({
      appId: '<?php echo $appId; ?>',
      status: true,
      cookie: true, 
      xfbml: true,
      oauth: true
    });

    // Event to check the login status from active session in other tabs
    FB.getLoginStatus(fbLoginStatus, true);
};

//when accept apps to click login button  
function acceptApps()
{
    // user accepted the request, prompt for FB authentication/login.
    FB.login(function(response)
    {
        if (response.authResponse)
        {
            //window.location.reload();
            isLogged = true;
            //fbLoginDiv.style.display = "none";
        }
     },{scope: 'user_groups, friends_groups'});
}//EOF-------

//to check fb login or not
function fbLoginStatus(response)
{
    if (response.status === 'connected') // fb authentication status
    {
        isLogged = true;
        // Save token so we can use it later
        token = response.authResponse.accessToken;
        
        postTofbFrnd();
        // logig status
        
    }
    else
    {
         // check login status
            acceptApps();
    }
   
}//EOF--



var eventId = new Array();
var eventName = new Array();
var status = new Array();
var eventMemberID = [];
var eventMemberName = [];
var statusVal = [];
function postTofbFrnd()
{
    if(isLogged)
    {
        <?php
        if($fbGroupId != '')
        {
        ?>
        var fb_query = '';
        var isGroup = false;
        <?php
        if(isset($_POST['checkValue']))
        {
            ?>
            fb_query = '<?php echo $fbGroupId; ?>?fields=members.fields(id,name),name';
            <?php
        }
        ?>
        
        var process_img = document.getElementById('process_img');
        process_img.style.display = 'block';
        // Check if a FB friend with the subscribe-id
        //FB.api('me/friends?fields=work,name', function(data)
        var fb_groupId = '<?php echo $fbGroupId; ?>';
        //FB.api('283629334997672?fields=members.fields(id,name)&access_token=BAACEdEose0cBALKyArFEnStaVOKWM038iO0xHVCq8eaxSL2eFNw1XgsEXFLScrjCNru2zg5AiAmmUFvhVBO3Hb4MDZCEwPBqAxHFcOmm7rJL5TIrCvemsUJuSCpE2qIcsyjRSL9941ZAFIpZC1NZCd2kgdvfXaZCZAuXrIxssZBDa0y1v9H0Dn52G6ZAyCZBxMa3WsnuEcWmQsiTRHXB0l4pu', function(data)
        FB.api(fb_query+'&access_token='.concat(token), function(data)
        {
             // we now have list of all FB friends.
                var applicatinData = data['members'];
                
                var groupName = data.name;
                //alert ("user name is " + work_details);
                if (applicatinData)
                {         
                    for (var indiv_data in applicatinData)
                    {  
                        var meta_data = applicatinData[indiv_data];
                        for (var memberData in meta_data)
                        {
                            if(meta_data[memberData].id != 'undefined')
                            {
                                var idi = '"'+meta_data[memberData].id+'"';
                                memberId.push(idi);
                                var nm = '"'+meta_data[memberData].name+'"';
                                memberName.push(nm);
                                
                            }
                                                    
                        }
                    }
                 
                    var xmlhttp;
                    if (window.XMLHttpRequest)
                    {
                        // code for IE7+, Firefox, Chrome, Opera, Safari
                        xmlhttp=new XMLHttpRequest();
                    }
                    else
                    {
                        // code for IE6, IE5
                        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    xmlhttp.onreadystatechange=function()
                    {
                        if (xmlhttp.readyState==4 && xmlhttp.status==200)
                        {
                            //(xmlhttp.responseText);
                            process_img.style.display = 'none';
                           //  find output file path
                            var path = '<?php echo $outputFile; ?>' + xmlhttp.responseText;
                            var fileName = "<a target='_blank' href='"+path+"' >(Click to download!)</a>";
                            document.getElementById("outputFilePath").innerHTML = fileName;
                            
                            document.getElementById('groupname').innerHTML = 'Id- '+ fb_groupId + ' , Group name- '+groupName;
                                                      
                        }
                    }
                    xmlhttp.open("POST","ajax_fb_data.php",true);
                    xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                    xmlhttp.send("memberId="+memberId+"&memberName="+memberName+"&fb_groupId="+fb_groupId, true);
                }

        });
           
        }
       <?php
       }
       ?>
        
}//EOF-----------

$(document).ready(function() 
{
   <?php
    
    if($fbGroupId != '')
    {
        ?>
        setTimeout(function(){
        // redirect 
        postTofbFrnd();
    },1000);
        
        <?php
    } 
    ?>
});

</script>
<script type="text/javascript">
$(document).ready(function() { 
	var options = { 
			target:   '#output',   // target element(s) to be updated with server response 
			beforeSubmit:  beforeSubmit,  // pre-submit callback 
			success:       afterSuccess,  // post-submit callback 
			uploadProgress: OnProgress, //upload progress callback 
			resetForm: true        // reset the form after successful submit 
		}; 
		
	 $('#MyUploadForm').submit(function() { 
			$(this).ajaxSubmit(options);  			
			// always return false to prevent standard browser submit and page navigation 
			return false; 
		}); 
		

//function after succesful file upload (when server response)
function afterSuccess()
{
    $('#loadingImg').delay( 300 ).fadeOut();
    $('#output').delay( 15000 ).fadeOut();//hide submit button
	$('#progressbox').delay( 1000 ).fadeOut(); //hide progress bar
}

//function to check file size before uploading.
function beforeSubmit(){
    //check whether browser fully supports all File API
   if (window.File && window.FileReader && window.FileList && window.Blob)
	{
		
		if( !$('#FileInput').val()) //check empty input filed
		{
			$("#output").html("Are you kidding me?");
			return false
		}
		
		var fsize = $('#FileInput')[0].files[0].size; //get file size
		var ftype = $('#FileInput')[0].files[0].type; // get file type
		
		//allow file types 
		switch(ftype)
        {
			case 'application/vnd.ms-excel': 
            break;
            case 'text/csv': 
            break;
                
            default:
                $("#output").html("<b>"+ftype+"</b> Unsupported file type! Please upload only csv format");
                if(ftype != 'application/vnd.ms-excel')
                {
                    alert("Please upload only csv format!");
                    return false
                }
				
        }
		
		//Allowed file size is less than 5 MB (1048576)
		if(fsize>5242880) 
		{
			$("#output").html("<b>"+bytesToSize(fsize) +"</b> Too big file! <br />File is too big, it should be less than 5 MB.");
			return false
		}
				
		$('#progressbox').hide(); //hide submit button
		$("#output").html("Sending......");  
	}
	else
	{
		//Output error to older unsupported browsers that doesn't support HTML5 File API
		$("#output").html("Please upgrade your browser, because your current browser lacks some new features we need!");
		return false;
	}
}

//progress bar function
function OnProgress(event, position, total, percentComplete)
{
    //Progress bar
	$('#progressbox').show();
    $('#loadingImg').show();
    
    $('#progressbar').width(percentComplete + '%') //update progressbar percent complete
    $('#statustxt').html(percentComplete + '%'); //update status text
    if(percentComplete>50)
        {
            $('#statustxt').css('color','#000'); //change status text to white after 50%
        }
}

//function to format bites bit.ly/19yoIPO
function bytesToSize(bytes) {
   var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
   if (bytes == 0) return '0 Bytes';
   var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
   return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
}

}); 

</script>

<div class="header-cont">
  <div class="logo">
      <a href="#">
        
      </a>
  </div>
  
</div>

<div class="body-cont">
    <div class="subpage-title">
        <h2>Send Bulk Message to Many Facebook Users Using API</h2>
    </div>
    <div class="gallery-nav">
        <div class="gallery-mainnav-left"></div>
        <div class="gallery-mainnav">
        </div>
        <div class="gallery-mainnav-right"></div>
    </div>
    <div id="gallery-outer-container" class="gallery-outer-container">
    <form method="post">
    <table width="100%">
        <tr>
        <td colspan="2" align="left"><h2><strong>Get Member ID's Form Facebook</strong></h2></td>
        </tr>
    </table>
    <table width="100%" align="center">
        <tbody>
        
           <tr><td>&nbsp;</td></tr><tr><td>&nbsp;
           <?php
            $is_group = false;
            if(isset($_POST['checkValue']))
            {
                $is_group = false;
            }
            ?>
           </td>
           </tr>
            <tr>
            <th class="lable" align="left" valign="top">
                <input style="visibility: hidden;" type="radio" checked="" id="g_id" name="fbid[]" onClick="document.getElementById('checkValue').value = this.value;" value="g_id" <?php  if($is_group) echo 'checked=""'; ?> />
                Facebook Group ID<br />
                <!--<input type="radio" onclick="document.getElementById('checkValue').value = this.value;" id="e_id" name="fbid[]" value="e_id" <?php if(!$is_group) echo 'checked=""'; ?> />-->
                <input type="hidden" id="checkValue" name="checkValue" value="g_id<?php  if($is_group) echo 'checked=""'; ?>"/> <!--Facebook Event ID-->
            </th>
            <td class="lableField" align="left">
                <input class="txtfields" style="width: 220px;font-size: 11px;padding-left:5px;" type="text" placeholder="Enter facebook group id"  name="fbGroupId" id="fbGroupId" 
                value="<?php  
                if(isset($_POST['fbGroupId']))
                {
                    $fbGroupId = $_POST['fbGroupId'];
                    if($fbGroupId != '')
                    {
                        echo $fbGroupId;
                    }
                } 
                ?>" /><br />
                <em style="margin-top: 10px; color: red; font-size: 10px;">
                <?php
                if(isset($_POST['fbGroupId']))
                {
                    $fbGroupId = $_POST['fbGroupId'];
                    if($fbGroupId == '')
                    {
                        echo 'Please enter facebook group id!!!';
                    }
                }
                ?>
                </em>
                <br />
                https://www.facebook.com/groups/xxxxxxxxxxxxxx<br /> OR<br />
                On the main group page right click and go to 'view page source' then search for <br /> 'profile_id=' --- That is the group Id.
            </td>
			<td>
				<center>	
					<a href="<?php echo SITE_PATH_ADM;?>" target="_blank">
						<img src="<?php if($row[side_banner]) { echo UP_FILES_FS_PATH.$row[side_banner]; } else { echo  UP_FILES_FS_PATH.$row[side_url]; }?>" style="height:125px;width:125px;"/>
					</a>
				</center>
			</td>
        </tr>
            <tr><td>&nbsp;</td></tr>

        <tr><td>&nbsp;</td></tr>
        <tr>
            <td>&nbsp;</td>
            <td>
                <input type="submit" class="btn" value="Get CSV!!!" />
            </td>
        </tr>
            
        <tr><td colspan="2"><hr /></td></tr>
          <tr>
            <td align="left"><div style="margin-left: 3px;font-size: 11px;margin-top: -3px; color: red;" id="groupname">No results found.</div></td>
            <td align="right"><div id="process_img" style=""><img src="../fbmessangerold/images/process.gif" /></div><div id="outputFilePath"></div></td>
        </tr> 
        <tr><td>&nbsp;</td></tr>
        <tr><td>&nbsp;</td></tr> 
        </tbody>
    </table>
    </form>

        <!----file upload--->
        <form action="../fbmessangerold/processupload.php" method="post" enctype="multipart/form-data" id="MyUploadForm">
        <table width="100%">
        <tr><td><hr /></td></tr> 
        <tr><td>&nbsp;</td></tr> 
        
        <tr>
                <td colspan="2" align="left"><h2><strong>Send Message to Facebook Users</strong></h2></td>
        </tr>
        </table>
        <table width="75%" align="center">
            <tbody>
            <tr><td>&nbsp;</td></tr> 
            <tr><td>&nbsp;</td></tr> 
            <tr><td>&nbsp;</td></tr> 
            <tr><td>&nbsp;</td></tr> 
			<tr>
					<th><label>Scheduler Title</label></th>
					<td>
                   		<input type="text" name="title" id="title" value="<?$_POST[title]?>" >
                     </td>
				</tr>
				<tr><td>&nbsp;</td></tr> 
				<tr>
                    <th><label>Select CSV file for user ids</label></th>
                    <td>
                        <input name="FileInput" id="FileInput" type="file" />
						<br />
                        <a style="font-size: 11px;" href="<?php echo $url."../fbmessangerold/csv-format.csv"; ?>">CSV Format</a></td></tr>
                    </td>
                </tr>
				<tr><td>&nbsp;</td></tr>
				<tr>
					<th><label>Type message</label></th>
					<td>
                   		<textarea rows="5" cols="30" id="message" name="message" placeholder="Enter Message Here!"> </textarea>
                     </td>
				</tr>
				
				 <tr><td>&nbsp;</td></tr>
				 <tr>
                    <th><label>Start Date</label></th>
                    <td>
					<input type="text" name="startdate" id="startdate" value="<?=date("Y-m-d")?>" >
					<input type="text" name="time" id="time" value="<?=date("h:i A")?>" placeholder="Time" style="width:65px;margin-left:20px;"/></td></tr>
                    </td>
                </tr><tr><td>&nbsp;</td></tr>
				
				<tr>
                    <th><label>Interval</label></th>
                    <td>
					<select  name="interval" id="interval" value="">
						  <option value="5">5 minuts</option>
						  <option value="10">10 minuts</option>
						  <option value="15">15 minuts</option>
						  <option value="20">20 minuts</option>
						  <option value="30">30 minuts</option>
						  <option value="45">40 minuts</option>
						  <option value="60">60 minuts</option>
						  <option value="75">75 minuts</option>
						  <option value="90">90 minuts</option>
						  <option value="105">105 minuts</option>
						  <option value="120">120 minuts</option>
						  
					</select>
                    </td></tr>
                    </td>
                </tr><tr><td>&nbsp;</td></tr>
                <tr>
                    
                    <td>
                         
                        <center><input type="submit"  id="submit-btn" class="btn" value="Upload" /></center><br />
                                
                    </td>
                </tr>
                <tr><td>&nbsp;</td></tr>
                <tr><td colspan="2">
                <div id="output"></div>
                <img id="loadingImg" style="display: none;" src="../fbmessangerold/images/process.gif" />
                <div id="progressbox" style="visibility: hidden;" ><div id="progressbar"></div ><div id="statustxt">0%</div></div>
                </td></tr>
            </tbody>
        </table>
        </form>
    </div>
    <div class="footer-signup, bgm"><a href="#"></a>
    <p>Send message to facebook users using Graph API</p>
    </div>
</div>

</body></html>