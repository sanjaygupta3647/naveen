-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- होस्ट: localhost
-- समय पर बनाया: 11 नवम्बर, 2014 को 05:33 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
--  डाटाबेस: `secondsells`
--

-- --------------------------------------------------------

--
-- Table structure for table `fz_administrator`
--

CREATE TABLE IF NOT EXISTS `fz_administrator` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ausername` varchar(255) DEFAULT NULL,
  `afname` varchar(255) NOT NULL,
  `alname` varchar(255) NOT NULL,
  `aemail` varchar(255) DEFAULT NULL,
  `apassword` varchar(255) NOT NULL,
  `atype` enum('su','admin','user') DEFAULT 'admin',
  `astatus` enum('Active','Inactive') DEFAULT 'Active',
  `submitdate` int(10) NOT NULL,
  PRIMARY KEY (`aid`),
  UNIQUE KEY `username` (`ausername`),
  KEY `first_name` (`afname`),
  KEY `last_name` (`alname`),
  KEY `password` (`apassword`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `fz_administrator`
--

INSERT INTO `fz_administrator` (`aid`, `ausername`, `afname`, `alname`, `aemail`, `apassword`, `atype`, `astatus`, `submitdate`) VALUES
(17, 'admin', 'John', 'Smith', 'watchcriclive@gmail.com', 'ZGVtb2RlbW8=', 'su', 'Active', 0),
(28, 'sanjay', 'sanjay', 'gupta', 'sanjay@gmail.com', 'ZGVtb2RlbW8=', 'user', 'Active', 1401646862);

-- --------------------------------------------------------

--
-- Table structure for table `fz_area`
--

CREATE TABLE IF NOT EXISTS `fz_area` (
  `pid` int(20) NOT NULL AUTO_INCREMENT,
  `city` varchar(150) NOT NULL,
  `areaname` varchar(150) NOT NULL,
  `pincode` varchar(150) NOT NULL,
  `store_user_id` int(15) NOT NULL,
  `day1` varchar(15) NOT NULL,
  `day2` varchar(15) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `fz_area`
--

INSERT INTO `fz_area` (`pid`, `city`, `areaname`, `pincode`, `store_user_id`, `day1`, `day2`, `status`) VALUES
(8, 'varanasi', 'Mohan  sraiy', '221311', 0, '', '', 'Active'),
(9, 'varanasi', 'Ramnagar ', '221113', 0, '', '', 'Active'),
(10, 'Dildar Nagar', 'test', '113444', 0, '', '', 'Active'),
(11, 'jamiya', 'test1', '110001', 0, '', '', 'Active'),
(12, 'Barely', 'barely', '110001', 0, '', '', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `fz_banner`
--

CREATE TABLE IF NOT EXISTS `fz_banner` (
  `pid` int(10) NOT NULL AUTO_INCREMENT,
  `banner` varchar(200) NOT NULL,
  `title` varchar(300) NOT NULL,
  `slider` varchar(200) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `fz_banner`
--

INSERT INTO `fz_banner` (`pid`, `banner`, `title`, `slider`, `status`) VALUES
(1, '205431401821316.jpg', 'hvfhcvhvjhc', '93101401821232.jpg', 'Active'),
(2, '49971406270994.jpg', 'TEST', '49971406270994.jpg', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `fz_category`
--

CREATE TABLE IF NOT EXISTS `fz_category` (
  `pid` int(15) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `body` text NOT NULL,
  `specifications` text NOT NULL,
  `parentId` int(20) NOT NULL,
  `porder` int(15) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('Active','Inactive') NOT NULL,
  `image` char(200) DEFAULT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `fz_category`
--

INSERT INTO `fz_category` (`pid`, `name`, `body`, `specifications`, `parentId`, `porder`, `date`, `status`, `image`) VALUES
(18, 'Real Estate', 'Real Estate', '', 0, 0, '2014-07-25 17:34:19', 'Active', '235451407055703.png'),
(19, 'mage', '', '', 18, 0, '2014-07-25 17:38:43', 'Active', NULL),
(20, 'Flower', 'sdcfsddsd', '', 20, 0, '2014-07-25 17:43:30', 'Active', NULL),
(21, 'Rose', 'asadsad', '', 21, 0, '2014-07-25 17:44:04', 'Active', NULL),
(22, 'Furniture', 'Furniture', '', 0, 0, '2014-07-25 17:48:47', 'Active', '318111407055690.png'),
(23, 'Rose', 'czvxcvcx', '', 22, 0, '2014-07-25 17:49:10', 'Active', NULL),
(24, 'Lotus', 'xcvcvxc', '', 22, 0, '2014-07-25 17:49:25', 'Active', NULL),
(25, 'Cosmetics', 'Cosmetics', '', 0, 0, '2014-08-03 08:52:05', 'Active', '141421407055708.png'),
(26, 'Electronics', 'Electronics', '', 0, 0, '2014-08-03 08:53:23', 'Active', '251171407055715.png'),
(27, 'Hotel', 'Hotel', '', 0, 0, '2014-08-03 08:54:19', 'Active', '119281407055721.png'),
(28, 'Books', 'Books', '', 0, 0, '2014-08-03 08:57:45', 'Active', '196021407055728.png'),
(29, 'Fashion', 'Fashion', '', 0, 0, '2014-08-03 08:58:17', 'Active', '180191407055736.png'),
(30, 'Cars', 'Cars', '', 0, 0, '2014-08-03 08:58:45', 'Active', '7041407055696.png');

-- --------------------------------------------------------

--
-- Table structure for table `fz_contact`
--

CREATE TABLE IF NOT EXISTS `fz_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `email` varchar(250) NOT NULL DEFAULT 'product',
  `subject` varchar(250) DEFAULT 'orginal',
  `message` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `fz_contact`
--

INSERT INTO `fz_contact` (`id`, `name`, `email`, `subject`, `message`) VALUES
(1, '93101401821232.jpg', 'product', '', ''),
(2, '205431401821316.jpg', 'product', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `fz_contact_us`
--

CREATE TABLE IF NOT EXISTS `fz_contact_us` (
  `pid` int(15) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `subject` varchar(250) NOT NULL,
  `massage` int(240) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `fz_images`
--

CREATE TABLE IF NOT EXISTS `fz_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(250) DEFAULT NULL,
  `path` varchar(250) NOT NULL DEFAULT 'product',
  `remark` varchar(200) DEFAULT 'orginal',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `fz_images`
--

INSERT INTO `fz_images` (`id`, `image`, `path`, `remark`) VALUES
(1, '93101401821232.jpg', 'product', ''),
(2, '205431401821316.jpg', 'product', ''),
(3, '289241406270986.jpg', 'product', ''),
(4, '49971406270994.jpg', 'product', ''),
(5, '121351406271020.png', 'product', ''),
(6, '325181406305175.png', 'product', ''),
(7, '65991406305185.png', 'product', ''),
(8, '194441406305197.png', 'product', ''),
(9, '318111407055690.png', 'category', ''),
(10, '7041407055696.png', 'category', ''),
(11, '235451407055703.png', 'category', ''),
(12, '141421407055708.png', 'category', ''),
(13, '251171407055715.png', 'category', ''),
(14, '119281407055721.png', 'category', ''),
(15, '196021407055728.png', 'category', ''),
(16, '180191407055736.png', 'category', '');

-- --------------------------------------------------------

--
-- Table structure for table `fz_pages`
--

CREATE TABLE IF NOT EXISTS `fz_pages` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `subpageid` int(10) DEFAULT '0',
  `pagename` varchar(255) NOT NULL,
  `heading` varchar(255) NOT NULL,
  `meta_title` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `meta_description` text NOT NULL,
  `sort_body` longtext NOT NULL,
  `body` longtext NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Inactive',
  `hnav` enum('yes','no') DEFAULT 'no',
  `fnav` enum('yes','no') DEFAULT 'no',
  `pimage` varchar(255) NOT NULL,
  `submitdate` int(11) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `fz_pages`
--

INSERT INTO `fz_pages` (`pid`, `subpageid`, `pagename`, `heading`, `meta_title`, `meta_keyword`, `meta_description`, `sort_body`, `body`, `url`, `status`, `hnav`, `fnav`, `pimage`, `submitdate`) VALUES
(2, 0, 'About Us', 'About Us', 'About Us', 'About Us', 'About Us', '', '<p style="clear: both;">\r\n	Curabitur tempus magna in enim vehicula vestibulum eu sed dui. Donec interdum lorem ante, id dapibus orci mollis ac. Donec a nisl sollicitudin, condimentum purus quis, tristique massa.</p>\r\n<p>\r\n	<br/></p>\r\n<p>\r\n	Nunc velit turpis, ornare quis scelerisque ut, varius sit amet sem. Integer eu varius dui, sed placerat turpis. Phasellus ut quam a urna ullamcorper aliquam non nec nisl. <a href="http://localhost/secondsells/">Quisque</a> imperdiet ligula urna, vel fermentum dui pretium vel. Maecenas commodo viverra mi et porta.</p>\r\n<p>\r\n	Sed et tellus a tellus consequat tincidunt. Proin a imperdiet massa, quis consectetur neque. Aenean ut tincidunt nulla. In consequat purus eu condimentum hendrerit. In tristique non metus ut mattis.</p>\r\n<p class="ss-block">\r\n	<span>1</span>Sed et tellus a tellus consequat tincidunt.<br />\r\n	Proin a imperdiet massa, quis consectetur neque. Aenean <a href="Javascript:void(0)">ut tincidunt nulla</a>. In consequat purus eu condimentum hendrerit. In tristique non metus ut mattis.</p>\r\n<p class="ss-block">\r\n	<span>2</span>Sed et tellus a tellus consequat tincidunt. Proin a imperdiet massa, quis consectetur neque.<br />\r\n	Aenean ut tincidunt nulla. In consequat purus eu condimentum hendrerit. In tristique non metus ut mattis.</p>\r\n<p>\r\n	<br />\r\n	<strong>Fusce at nisi mauris.</strong><br />\r\n	Mauris pretium, metus sed condimentum ullamcorper, erat nisi ultrices ipsum, quis pretium massa magna id justo. Mauris vitae venenatis tellus. Suspendisse id augue mauris. Morbi et velit sit amet erat consectetur pretium ac eleifend arcu.</p>\r\n<ul>\r\n	<li>\r\n		Duis vestibulum justo vitae turpis sagittis vestibulum. Donec <a href="Javascript:void(0)">posuere urna nulla, tempus venenatis</a> tortor gravida id.</li>\r\n	<li>\r\n		Quisque viverra est eu erat semper, ac ultricies dolor luctus. Sed ut erat egestas lacus pretium venenatis.</li>\r\n	<li>\r\n		Aliquam at sagittis enim. Nam varius condimentum porttitor. Aenean massa tellus, vestibulum in tempus sed, adipiscing eu odio. Mauris blandit porttitor convallis.</li>\r\n</ul>\r\n<p>\r\n	<br />\r\n	Phasellus ut quam a urna ullamcorper aliquam non nec nisl. Quisque imperdiet ligula urna, vel fermentum dui pretium vel. Maecenas commodo viverra mi et porta.</p>\r\n<p>\r\n	Sed et tellus a tellus consequat tincidunt. Proin a imperdiet massa, quis consectetur neque. Aenean ut tincidunt nulla. In consequat purus eu condimentum hendrerit. In tristique non metus ut mattis.</p>\r\n', 'about-us', 'Active', 'yes', 'yes', '', 1407053477),
(3, 0, 'Privacy Policy', 'Privacy Policy', '', '', '', '', '<ul>\r\n	<li>\r\n		Duis vestibulum justo vitae turpis sagittis vestibulum. Donec <a href="Javascript:void(0)">posuere urna nulla, tempus venenatis</a> tortor gravida id.</li>\r\n	<li>\r\n		Quisque viverra est eu erat semper, ac ultricies dolor luctus. Sed ut erat egestas lacus pretium venenatis.</li>\r\n	<li>\r\n		Aliquam at sagittis enim. Nam varius condimentum porttitor. Aenean massa tellus, vestibulum in tempus sed, adipiscing eu odio. Mauris blandit porttitor convallis.</li>\r\n</ul>\r\n<p>\r\n	Curabitur tempus magna in enim vehicula vestibulum eu sed dui. Donec interdum lorem ante, id dapibus orci mollis ac. Donec a nisl sollicitudin, condimentum purus quis, tristique massa. Nunc velit turpis, ornare quis scelerisque ut, varius sit amet sem. Integer eu varius dui, sed placerat turpis.</p>\r\n<p>\r\n	<br/></p>\r\n<p>\r\n	Phasellus ut quam a urna ullamcorper aliquam non nec nisl. <a href="Javascript:void(0)">Quisque</a> imperdiet ligula urna, vel fermentum dui pretium vel. Maecenas commodo viverra mi et porta.</p>\r\n<p>\r\n	Sed et tellus a tellus consequat tincidunt. Proin a imperdiet massa, quis consectetur neque. Aenean ut tincidunt nulla. In consequat purus eu condimentum hendrerit. In tristique non metus ut mattis.</p>\r\n<p>\r\n	Phasellus ut quam a urna ullamcorper aliquam non nec nisl. Quisque imperdiet ligula urna, vel fermentum dui pretium vel. Maecenas commodo viverra mi et porta.</p>\r\n<p>\r\n	Sed et tellus a tellus consequat tincidunt. Proin a imperdiet massa, quis consectetur neque. Aenean ut tincidunt nulla. In consequat purus eu condimentum hendrerit. In tristique non metus ut mattis.</p>\r\n<p class="ss-block">\r\n	<span>1</span>Sed et tellus a tellus consequat tincidunt.<br />\r\n	Proin a imperdiet massa, quis consectetur neque. Aenean <a href="Javascript:void(0)">ut tincidunt nulla</a>. In consequat purus eu condimentum hendrerit. In tristique non metus ut mattis.</p>\r\n<p class="ss-block">\r\n	<span>2</span>Sed et tellus a tellus consequat tincidunt. Proin a imperdiet massa, quis consectetur neque.<br />\r\n	Aenean ut tincidunt nulla. In consequat purus eu condimentum hendrerit. In tristique non metus ut mattis.</p>\r\n<p>\r\n	<br />\r\n	<strong>Fusce at nisi mauris.</strong><br />\r\n	Mauris pretium, metus sed condimentum ullamcorper, erat nisi ultrices ipsum, quis pretium massa magna id justo. Mauris vitae venenatis tellus. Suspendisse id augue mauris. Morbi et velit sit amet erat consectetur pretium ac eleifend arcu.</p>\r\n', 'privacy-policy', 'Active', 'no', 'no', '', 1407054182),
(4, 0, '', 'Contact Us', '', '', '', '', '<p>\r\n	Buisness Number : 455455</p>\r\n<p>\r\n	Email: abc@xyz.com</p>\r\n', 'contact-us', 'Active', 'no', 'no', '', 1415726257);

-- --------------------------------------------------------

--
-- Table structure for table `fz_product`
--

CREATE TABLE IF NOT EXISTS `fz_product` (
  `pid` int(15) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `short_title` varchar(200) NOT NULL,
  `meta_title` varchar(300) NOT NULL,
  `meta_description` varchar(200) NOT NULL,
  `meta_keyword` varchar(200) NOT NULL,
  `price` float NOT NULL,
  `offer_price` float NOT NULL,
  `state` varchar(220) NOT NULL,
  `city` varchar(200) NOT NULL,
  `area` varchar(200) NOT NULL,
  `image1` varchar(250) NOT NULL,
  `image2` varchar(250) NOT NULL,
  `image3` varchar(250) NOT NULL,
  `image4` varchar(250) NOT NULL,
  `image5` varchar(250) NOT NULL,
  `image6` varchar(250) NOT NULL,
  `image7` varchar(250) NOT NULL,
  `image8` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `submit_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `fz_product`
--

INSERT INTO `fz_product` (`pid`, `cat_id`, `title`, `short_title`, `meta_title`, `meta_description`, `meta_keyword`, `price`, `offer_price`, `state`, `city`, `area`, `image1`, `image2`, `image3`, `image4`, `image5`, `image6`, `image7`, `image8`, `description`, `status`, `submit_date`) VALUES
(21, 0, 'Jitendra', 'jbjbkjbkjb', 'jkbjkbjkbb', 'bjkbjkjkbjkb', 'jkbbjbbkjbkj', 2000, 2000, 'Bihar', 'jamiya', 'jamiya', '194441406305197.png', '49971406270994.jpg', '194441406305197.png', '289241406270986.jpg', '325181406305175.png', '205431401821316.jpg', '93101401821232.jpg', '205431401821316.jpg', '<p>\r\n	sdfdsfsdfsdfdfsfddffds</p>\r\n', 'Active', '2014-07-25 09:51:33'),
(22, 0, 'TEST', 'Sed sapien sapien, vulputate ac varius vitae, rutrum ultrices odio. Morbi vel tortor enim. Praesent lobortis gravida pretium. Vestibulum faucibus pellentesque metus, nec convallis mauris congue sed - ', 'Sed sapien sapien, vulputate ac varius vitae, rutrum ultrices odio. Morbi vel tortor enim. Praesent lobortis gravida pretium. Vestibulum faucibus pellentesque metus, nec convallis mauris congue sed - See more at: http://livedemo00.template-help.com/virtuemart_50537/index.php/online-store/reviews/pro', 'Sed sapien sapien, vulputate ac varius vitae, rutrum ultrices odio. Morbi vel tortor enim. Praesent lobortis gravida pretium. Vestibulum faucibus pellentesque metus, nec convallis mauris congue sed - ', 'Sed sapien sapien, vulputate ac varius vitae, rutrum ultrices odio. Morbi vel tortor enim. Praesent lobortis gravida pretium. Vestibulum faucibus pellentesque metus, nec convallis mauris congue sed - ', 30000, 30000, 'Uttar Pradesh', 'Noida', 'Sec-12', '194441406305197.png', '121351406271020.png', '', '', '', '', '', '', '<p>\r\n	xcvbxvcbvcxbcvbvcb</p>\r\n', 'Active', '2014-07-26 06:45:35');

-- --------------------------------------------------------

--
-- Table structure for table `fz_prod_images`
--

CREATE TABLE IF NOT EXISTS `fz_prod_images` (
  `pid` int(15) NOT NULL AUTO_INCREMENT,
  `prod_id` int(15) NOT NULL,
  `image_name` varchar(200) NOT NULL,
  `submit_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `fz_prod_images`
--

INSERT INTO `fz_prod_images` (`pid`, `prod_id`, `image_name`, `submit_date`) VALUES
(2, 19, '49971406270994.jpg', '2014-07-25 09:47:09'),
(3, 20, '121351406271020.png', '2014-07-25 09:50:03'),
(4, 21, '289241406270986.jpg', '2014-07-25 09:51:33');

-- --------------------------------------------------------

--
-- Table structure for table `fz_prod_specification`
--

CREATE TABLE IF NOT EXISTS `fz_prod_specification` (
  `pid` int(15) NOT NULL AUTO_INCREMENT,
  `prod_id` int(15) NOT NULL,
  `specification` text NOT NULL,
  `submit_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `fz_prod_specification`
--

INSERT INTO `fz_prod_specification` (`pid`, `prod_id`, `specification`, `submit_date`) VALUES
(1, 21, 'jitendra singh', '2014-07-25 09:51:33'),
(2, 21, 'jitendra', '2014-07-25 09:51:33'),
(3, 21, 'jitendra1000', '2014-07-25 09:51:33'),
(4, 21, 'jitendra4', '2014-07-25 09:51:33'),
(5, 22, 'xvcbxcvbvxcb', '2014-07-26 06:45:35');

-- --------------------------------------------------------

--
-- Table structure for table `fz_setting`
--

CREATE TABLE IF NOT EXISTS `fz_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company` varchar(255) DEFAULT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `paypal` varchar(255) NOT NULL,
  `fb` varchar(255) DEFAULT NULL,
  `tw` varchar(255) DEFAULT NULL,
  `lin` varchar(255) DEFAULT NULL,
  `gp` varchar(255) DEFAULT NULL,
  `yt` varchar(255) DEFAULT NULL,
  `mode` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `fz_setting`
--

INSERT INTO `fz_setting` (`id`, `company`, `address`, `phone`, `email`, `paypal`, `fb`, `tw`, `lin`, `gp`, `yt`, `mode`) VALUES
(1, 'admin', 'admin', '9891617198', 'sanjay.vns1987@gmail.com', 'sanjay.vns1987@gmail.com', 'http://www.facebook.com', 'https://twitter.com', 'http://www.linkedin.com', 'http://plus.google.com', 'http://www.youtube.com', 'testing');

-- --------------------------------------------------------

--
-- Table structure for table `fz_state`
--

CREATE TABLE IF NOT EXISTS `fz_state` (
  `pid` int(15) NOT NULL AUTO_INCREMENT,
  `city` varchar(150) NOT NULL,
  `state` varchar(150) NOT NULL,
  `state_id` int(15) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `fz_state`
--

INSERT INTO `fz_state` (`pid`, `city`, `state`, `state_id`, `status`) VALUES
(8, 'varanasi', 'Uttar Pradesh', 0, 'Inactive'),
(9, 'Noida', 'Uttar Pradesh', 0, 'Active'),
(10, 'Dildar Nagar', 'Bihar', 0, 'Active'),
(11, 'jamiya', 'Bihar', 0, 'Active'),
(12, 'Barely', 'Uttar Pradesh', 0, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `fz_store_menu`
--

CREATE TABLE IF NOT EXISTS `fz_store_menu` (
  `pid` int(15) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `parent` int(11) NOT NULL,
  `porder` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `image` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
